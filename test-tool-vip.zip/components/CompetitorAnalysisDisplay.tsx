import React from 'react';
import type { CompetitorAnalysis, SeriesBible } from '../types';
import { CheckIcon, XCircleIcon, SparklesIcon, BookOpenIcon, CopyIcon } from './IconComponents';

const CopyButton: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="absolute top-2 right-2 p-1.5 bg-gray-700/50 hover:bg-gray-600/70 rounded-md text-gray-300 transition"
      aria-label="Sao chép"
    >
      {copied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
    </button>
  );
};


interface CompetitorAnalysisDisplayProps {
  analysis: CompetitorAnalysis;
  seriesBible?: SeriesBible;
}

const InfoCard: React.FC<{title: string; items: string[]; icon: React.ReactNode; itemClassName: string}> = ({title, items, icon, itemClassName}) => (
    <div className="bg-gray-900 p-5 rounded-xl border border-gray-700">
        <h3 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-3">
            {icon}
            {title}
        </h3>
        <ul className="space-y-2">
            {items.map((item, index) => (
                <li key={index} className={`flex items-start gap-2 p-2 rounded-md ${itemClassName}`}>
                    <span className="mt-1 shrink-0">{icon}</span>
                    <span>{item}</span>
                </li>
            ))}
        </ul>
    </div>
);


export const CompetitorAnalysisDisplay: React.FC<CompetitorAnalysisDisplayProps> = ({ analysis, seriesBible }) => {
  const seriesBibleText = seriesBible ? JSON.stringify(seriesBible, null, 2) : '';

  return (
    <div className="space-y-6 animate-fade-in">
        <div>
            <h2 className="text-2xl font-semibold text-cyan-300 mb-4 border-b-2 border-cyan-800 pb-2">Phân tích Cấu trúc Video Đối thủ</h2>
             <div className="space-y-3">
                 {analysis.structuralAnalysis.map((item, index) => (
                    <div key={index} className="bg-gray-900 p-4 rounded-lg border-l-4 border-gray-600">
                        <p className="font-semibold text-gray-200">{item.phan_doan}</p>
                        <p className="text-gray-400 text-sm mt-1">{item.mo_ta}</p>
                    </div>
                 ))}
             </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
            <InfoCard 
                title="Điểm Mạnh"
                items={analysis.strengths}
                icon={<CheckIcon className="w-5 h-5 text-green-400"/>}
                itemClassName="bg-green-900/30 text-green-200"
            />
             <InfoCard 
                title="Điểm Yếu"
                items={analysis.weaknesses}
                icon={<XCircleIcon className="w-5 h-5 text-red-400"/>}
                itemClassName="bg-red-900/30 text-red-200"
            />
        </div>

        <div>
            <InfoCard 
                title="Lỗ hổng Nội dung (Cơ hội)"
                items={analysis.contentGaps}
                icon={<SparklesIcon className="w-5 h-5 text-yellow-400"/>}
                itemClassName="bg-yellow-900/30 text-yellow-200"
            />
        </div>

        {seriesBible && (
            <div className="border-t-2 border-dashed border-cyan-800 pt-6">
                <h2 className="text-2xl font-semibold text-cyan-300 mb-4 flex items-center gap-3">
                    <BookOpenIcon className="w-7 h-7" />
                    SERIES BIBLE (Dùng cho các tập sau)
                </h2>
                <div className="relative bg-gray-900 p-4 rounded-xl border border-cyan-700">
                    <p className="text-sm text-gray-400 mb-2">Tệp này chứa thông tin cốt lõi để duy trì tính nhất quán cho series. Tải xuống và sử dụng nó khi tạo tập tiếp theo.</p>
                    <pre className="text-sm text-purple-300 bg-gray-800 p-3 rounded-md overflow-x-auto font-mono">
                        <code>{seriesBibleText}</code>
                    </pre>
                    <CopyButton textToCopy={seriesBibleText} />
                </div>
            </div>
        )}
    </div>
  );
};