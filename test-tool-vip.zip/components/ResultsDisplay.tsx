import React, { useState, useEffect, useRef } from 'react';
import type { AnalysisAndScript, Scene } from '../types';
import { DownloadIcon, SaveIcon, ChevronDownIcon, BookOpenIcon, FilmIcon } from './IconComponents';
import { CompetitorAnalysisDisplay } from './CompetitorAnalysisDisplay';
import { OptimizedScriptDisplay } from './OptimizedScriptDisplay';

type Tab = 'analysis' | 'script';

interface ResultsDisplayProps {
  result: AnalysisAndScript;
  onSave: (result: AnalysisAndScript) => void;
  isSaved: boolean;
}

const downloadTextFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

const downloadJsonFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

const downloadCSVFile = (content: string, filename: string) => {
    const csvContent = "\uFEFF" + content; // BOM for UTF-8 in Excel
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, onSave, isSaved }) => {
  const [activeTab, setActiveTab] = useState<Tab>('analysis');
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setDropdownOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleDownloadReport = () => {
    const { competitorAnalysis, optimizedScript, suggestions } = result;
    let content = `BÁO CÁO PHÂN TÍCH & KỊCH BẢN CẠNH TRANH\n`;
    content += `=========================================\n\n`;

    content += `=== GIAI ĐOẠN 1: PHÂN TÍCH ĐỐI THỦ ===\n\n`;
    content += `--- Cấu trúc Video ---\n`;
    competitorAnalysis.structuralAnalysis.forEach(item => {
        content += `${item.phan_doan}: ${item.mo_ta}\n`;
    });
    content += `\n--- Điểm mạnh ---\n- ${competitorAnalysis.strengths.join('\n- ')}\n`;
    content += `\n--- Điểm yếu ---\n- ${competitorAnalysis.weaknesses.join('\n- ')}\n`;
    content += `\n--- Lỗ hổng nội dung ---\n- ${competitorAnalysis.contentGaps.join('\n- ')}\n`;
    
    content += `\n\n=== GIAI ĐOẠN 2: KỊCH BẢN TỐI ƯU HÓA & ĐỀ XUẤT ===\n\n`;
    content += `--- Đề xuất Tiêu đề ---\n- ${suggestions.titles.join('\n- ')}\n`;
    content += `\n--- Đề xuất Ý tưởng Thumbnail ---\n- ${suggestions.thumbnailIdeas.join('\n- ')}\n\n`;

    const { overview, seo, intro, body, outro } = optimizedScript;
    const allScenes = [...(intro || []), ...(body || []), ...(outro || [])];
    const overviewText = `Tóm tắt: ${overview.tom_tat}\nBối cảnh: ${overview.boi_canh}\nPhong cách hình ảnh: ${overview.phong_cach_hinh_anh}\nHồ sơ nhân vật: ${overview.ho_so_nhan_vat}\nTông giọng: ${overview.tong_giong}`;
    const seoText = `Tiêu đề: ${seo.tieu_de}\nTừ khóa chính: ${seo.tu_khoa_chinh.join(', ')}\nTừ khóa phụ: ${seo.tu_khoa_phu.join(', ')}\nTừ khóa liên quan: ${seo.tu_khoa_lien_quan.join(', ')}`;
    
    const formatScenes = (title: string, scenes: Scene[]) => {
        if (!scenes || scenes.length === 0) return '';
        const scenesText = scenes.map(s => `\n--- Cảnh ${s.sceneNumber} ---\nBối cảnh: ${s.setting}\nPrompt Ảnh: ${s.imagePrompt}\nNegative Prompt Ảnh: ${s.negativeImagePrompt}\nPrompt Chuyển động: ${JSON.stringify(s.motionPrompt, null, 2)}`).join('\n');
        return `\n\n--- ${title.toUpperCase()} ---${scenesText}`;
    }

    content += `--- TỔNG QUAN KỊCH BẢN ---\n${overviewText}\n\n--- SEO ---\n${seoText}`;
    content += formatScenes('Mở đầu', intro);
    content += formatScenes('Thân bài', body);
    content += formatScenes('Kết luận', outro);

    const filename = `report_${result.id.split('_')[1]}.txt`;
    downloadTextFile(content, filename);
    setDropdownOpen(false);
  }

  const handleDownloadScreenplay = () => {
    const { optimizedScript } = result;
    const allScenes = [...(optimizedScript.intro || []), ...(optimizedScript.body || []), ...(optimizedScript.outro || [])];
    
    let content = `KỊCH BẢN\n`;
    content += `Tiêu đề: ${optimizedScript.seo.tieu_de}\n`;
    content += `=========================================\n\n`;

    allScenes.forEach(scene => {
        content += `CẢNH ${scene.sceneNumber}. ${scene.setting.toUpperCase()}\n\n`;
        content += `${scene.motionPrompt.action}\n\n`;
        content += `LỜI THOẠI:\n`;
        content += `${scene.motionPrompt.dialogue}\n\n`;
        content += `-----------------------------------------\n\n`;
    });
    
    const filename = `screenplay_${result.id.split('_')[1]}.txt`;
    downloadTextFile(content, filename);
    setDropdownOpen(false);
  };

  const handleDownloadPrompts = () => {
    const { optimizedScript } = result;
    const allScenes = [...(optimizedScript.intro || []), ...(optimizedScript.body || []), ...(optimizedScript.outro || [])];
    
    const content = allScenes
      .map(scene => scene.imagePrompt)
      .join('\n');
    
    const filename = `image_prompts_${result.id.split('_')[1]}.txt`;
    downloadTextFile(content, filename);
    setDropdownOpen(false);
  };

  const formatSrtTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const milliseconds = Math.round((totalSeconds * 1000) % 1000);

    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')},${String(milliseconds).padStart(3, '0')}`;
  };

  const handleDownloadSubtitles = () => {
    const { optimizedScript } = result;
    const allScenes = [...(optimizedScript.intro || []), ...(optimizedScript.body || []), ...(optimizedScript.outro || [])];
    
    let srtContent = '';
    const sceneDuration = 8; // Each scene is ~8 seconds

    allScenes.forEach((scene, index) => {
        if(scene.motionPrompt.dialogue && scene.motionPrompt.dialogue.trim() !== "") {
            const startTime = index * sceneDuration;
            const endTime = (index * sceneDuration) + sceneDuration;
            
            srtContent += `${index + 1}\n`;
            srtContent += `${formatSrtTime(startTime)} --> ${formatSrtTime(endTime)}\n`;
            srtContent += `${scene.motionPrompt.dialogue}\n\n`;
        }
    });
    
    const filename = `subtitles_${result.id.split('_')[1]}.srt`;
    downloadTextFile(srtContent, filename);
    setDropdownOpen(false);
  };

  const handleDownloadMotionPromptsAsJsonLines = () => {
    const { optimizedScript } = result;
    const allScenes = [...(optimizedScript.intro || []), ...(optimizedScript.body || []), ...(optimizedScript.outro || [])];
    
    const content = allScenes
      .map(scene => JSON.stringify(scene.motionPrompt))
      .join('\n');
    
    const filename = `motion_prompts_jsonl_${result.id.split('_')[1]}.txt`;
    downloadTextFile(content, filename);
    setDropdownOpen(false);
  };

  const handleDownloadStoryboardCSV = () => {
    const { optimizedScript } = result;
    const allScenes = [...(optimizedScript.intro || []), ...(optimizedScript.body || []), ...(optimizedScript.outro || [])];

    const escapeCsvCell = (cellData: string | number) => {
        const cellString = String(cellData || "").replace(/"/g, '""');
        return `"${cellString}"`;
    };
    
    const headers = ["Cảnh", "Camera Movement", "Sound Effects", "Background Music", "Visuals Notes"];
    let csvContent = headers.join(',') + '\n';

    allScenes.forEach(scene => {
        const row = [
            scene.sceneNumber,
            scene.motionPrompt.camera_movement,
            scene.motionPrompt.sound_effects,
            scene.motionPrompt.background_music,
            scene.motionPrompt.visuals_notes,
        ].map(escapeCsvCell).join(',');
        csvContent += row + '\n';
    });

    const filename = `storyboard_${result.id.split('_')[1]}.csv`;
    downloadCSVFile(csvContent, filename);
    setDropdownOpen(false);
  };
  
  const handleDownloadSeriesBible = () => {
    if (!result.seriesBible) return;
    const content = JSON.stringify(result.seriesBible, null, 2);
    const filename = `series_bible_${result.id.split('_')[1]}.json`;
    downloadJsonFile(content, filename);
    setDropdownOpen(false);
  };


  const TabButton: React.FC<{tab: Tab, label: string}> = ({tab, label}) => (
      <button
        onClick={() => setActiveTab(tab)}
        className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
            activeTab === tab 
            ? 'bg-gray-900 text-cyan-400 border-b-2 border-cyan-400' 
            : 'text-gray-400 hover:text-white'
        }`}
      >
        {label}
      </button>
  );

  return (
    <div className="h-full flex flex-col">
        <div className="flex items-center justify-between border-b border-gray-700 mb-4 shrink-0">
            <div className="flex items-center gap-2">
                <TabButton tab="analysis" label="Phân tích & Series Bible" />
                <TabButton tab="script" label="Kịch bản Tối ưu" />
            </div>
             <div className="flex items-center gap-2 pb-1">
                <button
                    onClick={() => onSave(result)}
                    disabled={isSaved}
                    className="flex items-center gap-2 px-3 py-1.5 bg-green-600 hover:bg-green-700 disabled:bg-gray-500 text-white font-bold rounded-lg transition-colors duration-300 text-sm"
                >
                    <SaveIcon className="w-4 h-4"/>
                    {isSaved ? 'Đã lưu' : 'Lưu'}
                </button>
                <div className="relative" ref={dropdownRef}>
                    <button
                        onClick={() => setDropdownOpen(prev => !prev)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors duration-300 text-sm"
                    >
                        <DownloadIcon className="w-4 h-4"/>
                        Tải xuống
                        <ChevronDownIcon className="w-4 h-4" />
                    </button>
                    {isDropdownOpen && (
                        <div className="absolute right-0 mt-2 w-80 origin-top-right bg-gray-700 border border-gray-600 rounded-md shadow-lg z-20 animate-fade-in-fast">
                            <div className="py-1">
                                <button onClick={handleDownloadReport} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">Toàn bộ Báo cáo (.txt)</button>
                                <button onClick={handleDownloadScreenplay} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">Chỉ Kịch bản (.txt)</button>
                                <button onClick={handleDownloadPrompts} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">Prompt tạo ảnh</button>
                                <button onClick={handleDownloadMotionPromptsAsJsonLines} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">Prompts Chuyển động (JSON Lines, 1 prompt/dòng)</button>
                                <button onClick={handleDownloadStoryboardCSV} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">Bảng Phân cảnh (.csv)</button>
                                <div className="border-t border-gray-600 my-1"></div>
                                <button onClick={handleDownloadSubtitles} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">
                                    <div className="flex items-center gap-2">
                                        <FilmIcon className="w-4 h-4 text-yellow-300"/> Phụ đề Video (.srt)
                                    </div>
                                </button>
                                {result.seriesBible && <div className="border-t border-gray-600 my-1"></div>}
                                {result.seriesBible && (
                                    <button onClick={handleDownloadSeriesBible} className="text-left w-full block px-4 py-2 text-sm text-gray-200 hover:bg-gray-600">
                                        <div className="flex items-center gap-2">
                                            <BookOpenIcon className="w-4 h-4 text-cyan-300"/> Series Bible (.json)
                                        </div>
                                    </button>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>

      <div className="overflow-y-auto pr-2 -mr-2 flex-grow bg-gray-900/50 rounded-b-lg">
        <div className="p-4">
            {activeTab === 'analysis' && <CompetitorAnalysisDisplay analysis={result.competitorAnalysis} seriesBible={result.seriesBible} />}
            {activeTab === 'script' && <OptimizedScriptDisplay script={result.optimizedScript} suggestions={result.suggestions} />}
        </div>
      </div>
    </div>
  );
};