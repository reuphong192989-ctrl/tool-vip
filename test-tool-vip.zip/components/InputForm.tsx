import React, { useState, useCallback, useMemo } from 'react';
import { LinkIcon, PhotoIcon, ClockIcon, XCircleIcon, SparklesIcon, FilmIcon, LanguageIcon, SpeakerWaveIcon, PencilSquareIcon, KeyIcon, ArrowUpTrayIcon, UserIcon } from './IconComponents';
import { suggestKeywords } from '../services/geminiService';
import type { GenerationOptions } from '../services/geminiService';
import { LAO_TI_SERIES_BIBLE, EXAMPLE_LAST_SCENE, EXAMPLE_NEW_EPISODE_TOPIC } from './exampleData';


interface InputFormProps {
  onGenerate: (options: GenerationOptions) => void;
  isLoading: boolean;
}
const defaultGenre = 'Mặc định (Theo video đối thủ / series)';

const genreOptions = [
  defaultGenre,
    'Tình cảm/Lãng mạn: Chuyện tình học trò',
    'Tình cảm/Lãng mạn: Tình yêu công sở',
    'Hài kịch: Tiểu phẩm ngắn châm biếm',
    'Hài kịch: Tình huống gây cười',
    'Kinh dị/Giật gân',
    'Khoa học viễn tưởng',
    'Xuyên không',
    'Phim Hành động kịch tính',
    'Hoạt hình 3D: Phong cách Pixar',
    'Hoạt hình 3D: Phong cách Dreamworks',
    'Hoạt hình 3D: Phong cách Anime/Cel-shaded',
    'Tài liệu lịch sử',
    'Blog chia sẻ',
    'Storyboard',
];

const languageOptions = ['Tiếng Việt', 'Tiếng Anh (US)'];
const voiceOptions = ['Giọng nam', 'Giọng nữ', 'Giọng trẻ em', 'Giọng người già'];

export const InputForm: React.FC<InputFormProps> = ({ onGenerate, isLoading }) => {
  const [scriptType, setScriptType] = useState<'analysis' | 'series'>('analysis');

  // Analysis state
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [userYoutubeUrl, setUserYoutubeUrl] = useState<string>('');
  const [referenceImages, setReferenceImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [competitiveAngle, setCompetitiveAngle] = useState<string>('');
  const [targetKeywordsInput, setTargetKeywordsInput] = useState<string>('');
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([]);
  const [isKeywordsLoading, setIsKeywordsLoading] = useState<boolean>(false);
  const [keywordsError, setKeywordsError] = useState<string | null>(null);

  // Series state
  const [seriesBibleJson, setSeriesBibleJson] = useState<string>('');
  const [lastSceneJson, setLastSceneJson] = useState<string>('');
  const [newEpisodeTopic, setNewEpisodeTopic] = useState<string>('');

  // Common state
  const [scriptDuration, setScriptDuration] = useState<string>('1');
  const [genre, setGenre] = useState<string>(genreOptions[0]);
  const [language, setLanguage] = useState<string>(languageOptions[0]);
  const [voice, setVoice] = useState<string>(voiceOptions[0]);
  const [error, setError] = useState<string | null>(null);
  
  const numberOfScenes = useMemo(() => {
    const durationInMinutes = parseInt(scriptDuration, 10);
    if (isNaN(durationInMinutes)) return 0;
    return Math.round((durationInMinutes * 60) / 8);
  }, [scriptDuration]);

  const handleImageChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;

    setReferenceImages(prevImages => {
      if (prevImages.length + files.length > 4) {
        setError('Bạn chỉ có thể tải lên tối đa 4 ảnh.');
        return prevImages;
      }
      setError(null);
      files.forEach((file: File) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (reader.result) {
            setImagePreviews(prevPreviews => [...prevPreviews, reader.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
      return [...prevImages, ...files];
    });
  }, []);
  
  const removeImage = (index: number) => {
    setReferenceImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  }

  const handleBibleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        try {
          // Validate it's JSON
          JSON.parse(content);
          setSeriesBibleJson(content);
          setError(null);
        } catch (error) {
          setError('File không chứa nội dung JSON hợp lệ.');
        }
      };
      reader.onerror = () => {
        setError('Không thể đọc file.');
      };
      reader.readAsText(file);
    }
  };

  const handleLoadExample = () => {
    setSeriesBibleJson(JSON.stringify(LAO_TI_SERIES_BIBLE, null, 2));
    setLastSceneJson(JSON.stringify(EXAMPLE_LAST_SCENE, null, 2));
    setNewEpisodeTopic(EXAMPLE_NEW_EPISODE_TOPIC);
    setError(null);
  };

  const handleSuggestKeywords = async () => {
    if (!youtubeUrl) {
      setKeywordsError('Vui lòng nhập URL YouTube trước.');
      return;
    }
    setIsKeywordsLoading(true);
    setKeywordsError(null);
    setSuggestedKeywords([]);
    setSelectedKeywords([]);
    try {
      const keywords = await suggestKeywords(youtubeUrl);
      setSuggestedKeywords(keywords);
    } catch (err) {
      setKeywordsError(err instanceof Error ? err.message : 'Không thể gợi ý từ khóa.');
    } finally {
      setIsKeywordsLoading(false);
    }
  };

  const toggleKeyword = (keyword: string) => {
    setSelectedKeywords(prev => 
      prev.includes(keyword)
        ? prev.filter(k => k !== keyword)
        : [...prev, keyword]
    );
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    const commonOptions = { scriptDuration, genre, language, voice };

    if (scriptType === 'series') {
        if (!seriesBibleJson.trim() || !lastSceneJson.trim() || !newEpisodeTopic.trim()) {
            setError('Vui lòng cung cấp đủ Series Bible, Cảnh Cuối, và Chủ đề Tập mới.');
            return;
        }
        try {
            JSON.parse(seriesBibleJson); // Validate bible content
            JSON.parse(lastSceneJson); // Validate last scene JSON
            
            onGenerate({
                scriptType: 'series',
                ...commonOptions,
                seriesBibleContent: seriesBibleJson,
                lastSceneJson,
                newEpisodeTopic,
            });

        } catch (err) {
            if (err instanceof SyntaxError) {
                setError('Nội dung Series Bible hoặc Cảnh Cuối không phải là JSON hợp lệ.');
            } else {
                setError('Đã xảy ra lỗi khi xử lý dữ liệu đầu vào.');
            }
            return;
        }
    } else { // Analysis mode
        if (!youtubeUrl) {
          setError('Vui lòng cung cấp URL video YouTube.');
          return;
        }
        if (referenceImages.length === 0) {
          setError('Vui lòng tải lên ít nhất một ảnh tham chiếu.');
          return;
        }
        const targetKeywords = targetKeywordsInput.split(',').map(k => k.trim()).filter(Boolean);
        if (targetKeywords.length > 5) {
          setError('Chỉ được nhập tối đa 5 từ khóa SEO mục tiêu.');
          return;
        }
        onGenerate({
            scriptType: 'analysis',
            ...commonOptions,
            youtubeUrl,
            userYoutubeUrl,
            referenceImages,
            suggestedKeywords: selectedKeywords,
            competitiveAngle,
            targetKeywords,
        });
    }
  };

  const durationOptions = [
    { value: '1', label: '1 Phút' }, { value: '2', label: '2 Phút' },
    { value: '3', label: '3 Phút' }, { value: '5', label: '5 Phút' },
    { value: '8', label: '8 Phút' }, { value: '10', label: '10 Phút' },
    { value: '12', label: '12 Phút' }, { value: '15', label: '15 Phút' },
  ];

  const renderAnalysisForm = () => (
    <>
      <div>
        <label htmlFor="youtubeUrl" className="block text-sm font-medium text-gray-300 mb-2">
          URL Video Đối Thủ
        </label>
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <LinkIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="url"
            id="youtubeUrl"
            value={youtubeUrl}
            onChange={(e) => setYoutubeUrl(e.target.value)}
            placeholder="https://www.youtube.com/watch?v=..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            required={scriptType === 'analysis'}
          />
        </div>
      </div>
      <div>
        <label htmlFor="userYoutubeUrl" className="block text-sm font-medium text-gray-300 mb-2">
          URL Kênh/Video của bạn (Tùy chọn, để tham khảo phong cách)
        </label>
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <UserIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="url"
            id="userYoutubeUrl"
            value={userYoutubeUrl}
            onChange={(e) => setUserYoutubeUrl(e.target.value)}
            placeholder="https://www.youtube.com/channel/..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          />
        </div>
        <p className="mt-2 text-xs text-gray-400">Cung cấp link video hoặc kênh của bạn để AI học hỏi phong cách biên tập, nhịp độ và tông giọng đặc trưng.</p>
      </div>
      <div>
        <label htmlFor="competitiveAngle" className="block text-sm font-medium text-gray-300 mb-2">
          Góc nhìn/Mục tiêu Cạnh tranh
        </label>
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 pt-3">
            <PencilSquareIcon className="h-5 w-5 text-gray-400" />
          </div>
          <textarea
            id="competitiveAngle"
            value={competitiveAngle}
            onChange={(e) => setCompetitiveAngle(e.target.value)}
            rows={3}
            placeholder="Ví dụ: Tạo ra một phiên bản có cốt truyện sâu sắc hơn..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          />
        </div>
      </div>
      <div>
        <label htmlFor="targetKeywords" className="block text-sm font-medium text-gray-300 mb-2">
          Từ khóa SEO Mục tiêu (Tối đa 5, phân cách bằng dấu phẩy)
        </label>
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <KeyIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            id="targetKeywords"
            value={targetKeywordsInput}
            onChange={(e) => setTargetKeywordsInput(e.target.value)}
            placeholder="phim ngắn tình cảm, review phim, hài tết..."
            className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          />
        </div>
      </div>
      <div>
        <button
          type="button"
          onClick={handleSuggestKeywords}
          disabled={isKeywordsLoading || !youtubeUrl}
          className="w-full flex justify-center items-center gap-2 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300 disabled:cursor-not-allowed"
        >
          {isKeywordsLoading ? (
            <><div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div><span>Đang tìm...</span></>
          ) : (
            <><SparklesIcon className="h-5 w-5" />Gợi ý từ khóa (để tham khảo)</>
          )}
        </button>
        {keywordsError && <p className="text-sm text-red-400 mt-2">{keywordsError}</p>}
        {suggestedKeywords.length > 0 && (
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">Chọn từ khóa để tham khảo:</label>
            <div className="flex flex-wrap gap-2">
              {suggestedKeywords.map(keyword => (
                <button key={keyword} type="button" onClick={() => toggleKeyword(keyword)}
                  className={`px-3 py-1 text-sm rounded-full transition-colors ${selectedKeywords.includes(keyword) ? 'bg-cyan-600 text-white' : 'bg-gray-700 text-gray-200 hover:bg-gray-600'}`}>
                  {keyword}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Ảnh tham chiếu ({referenceImages.length}/4)</label>
        {imagePreviews.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
            {imagePreviews.map((src, index) => (
              <div key={index} className="relative group">
                <img src={src} alt={`Preview ${index}`} className="h-24 w-full rounded-md object-cover" />
                <button type="button" onClick={() => removeImage(index)}
                  className="absolute top-0 right-0 m-1 bg-black/50 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remove image">
                  <XCircleIcon className="w-6 h-6"/>
                </button>
              </div>
            ))}
          </div>
        )}
        <div className="mt-2 flex justify-center rounded-lg border-2 border-dashed border-gray-600 px-6 py-10 hover:border-cyan-500 transition">
          <div className="text-center">
            <PhotoIcon className="mx-auto h-12 w-12 text-gray-400" />
            <div className="mt-4 flex text-sm leading-6 text-gray-400">
              <label htmlFor="file-upload"
                className="relative cursor-pointer rounded-md font-semibold text-cyan-400 focus-within:outline-none focus-within:ring-2 focus-within:ring-cyan-600 focus-within:ring-offset-2 focus-within:ring-offset-gray-900 hover:text-cyan-300">
                <span>Tải ảnh lên</span>
                <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" multiple onChange={handleImageChange} disabled={referenceImages.length >= 4}/>
              </label>
              <p className="pl-1">hoặc kéo và thả</p>
            </div>
            <p className="text-xs leading-5 text-gray-500">PNG, JPG, GIF tối đa 10MB</p>
          </div>
        </div>
      </div>
    </>
  );

  const renderSeriesForm = () => (
    <div className="border-2 border-dashed border-cyan-700 bg-cyan-900/10 p-4 rounded-lg space-y-6">
        <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-cyan-300">THIẾT LẬP SERIES (Tập Nối Tiếp)</h3>
            <button
              type="button"
              onClick={handleLoadExample}
              className="flex items-center gap-2 px-3 py-1.5 bg-yellow-600 hover:bg-yellow-700 text-white font-semibold rounded-lg transition-colors duration-300 text-sm"
            >
              <SparklesIcon className="h-4 w-4" />
              Tải Ví dụ "Lão Tí Capybara"
            </button>
        </div>
        <div>
            <label htmlFor="seriesBible" className="block text-sm font-medium text-gray-300 mb-2">
                1. Dán JSON của Series Bible hoặc
                 <label htmlFor="series-bible-upload"
                    className="relative cursor-pointer rounded-md font-semibold text-cyan-400 focus-within:outline-none hover:text-cyan-300 pl-1">
                    tải lên từ tệp...
                    <input id="series-bible-upload" name="series-bible-upload" type="file" className="sr-only" accept=".json,.txt" onChange={handleBibleFileChange} />
                </label>
            </label>
             <textarea
                id="seriesBible"
                value={seriesBibleJson}
                onChange={(e) => setSeriesBibleJson(e.target.value)}
                rows={6}
                placeholder='{ "ho_so_nhan_vat": "...", "phong_cach_hinh_anh": "...", ... }'
                className="w-full bg-gray-900 border border-gray-600 rounded-lg py-2 px-3 text-gray-100 font-mono text-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            />
        </div>
        <div>
            <label htmlFor="lastScene" className="block text-sm font-medium text-gray-300 mb-2">
                2. Dán JSON Cảnh Cuối của Tập Trước
            </label>
            <textarea
                id="lastScene"
                value={lastSceneJson}
                onChange={(e) => setLastSceneJson(e.target.value)}
                rows={4}
                placeholder='{ "sceneNumber": 15, "setting": "Trong căn phòng...", ... }'
                className="w-full bg-gray-900 border border-gray-600 rounded-lg py-2 px-3 text-gray-100 font-mono text-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            />
        </div>
        <div>
            <label htmlFor="newEpisodeTopic" className="block text-sm font-medium text-gray-300 mb-2">
                3. Chủ đề/Ý tưởng cho Tập Mới
            </label>
            <input
                type="text"
                id="newEpisodeTopic"
                value={newEpisodeTopic}
                onChange={(e) => setNewEpisodeTopic(e.target.value)}
                placeholder="Ví dụ: Lão Tí làm Mukbang và gặp đối thủ Capybara mới"
                className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 px-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            />
        </div>
    </div>
  );

  return (
    <div className="bg-gray-800 rounded-2xl p-6 shadow-2xl border border-gray-700">
      <h2 className="text-2xl font-bold mb-6 text-cyan-400">Thông tin đầu vào</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        
        <div>
          <label htmlFor="scriptType" className="block text-sm font-medium text-gray-300 mb-2">Loại kịch bản sẽ tạo</label>
          <select id="scriptType" value={scriptType} onChange={(e) => setScriptType(e.target.value as 'analysis' | 'series')}
            className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-4 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 appearance-none transition">
            <option value="analysis">Phân tích Cạnh Tranh (Tạo Tập 1)</option>
            <option value="series">Phát triển Series (Tạo Tập Nối Tiếp)</option>
          </select>
        </div>

        {scriptType === 'analysis' ? renderAnalysisForm() : renderSeriesForm()}

        <div className="border-t border-gray-700 pt-6 space-y-6">
            <h3 className="text-lg font-bold text-cyan-300">Thiết lập Chung</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="genre" className="block text-sm font-medium text-gray-300 mb-2">Thể loại</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><FilmIcon className="h-5 w-5 text-gray-400" /></div>
                    <select id="genre" value={genre} onChange={(e) => setGenre(e.target.value)}
                      className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 appearance-none transition">
                      {genreOptions.map(option => (<option key={option} value={option}>{option}</option>))}
                    </select>
                  </div>
                </div>
                
                 <div>
                  <label htmlFor="language" className="block text-sm font-medium text-gray-300 mb-2">Ngôn ngữ thoại</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><LanguageIcon className="h-5 w-5 text-gray-400" /></div>
                    <select id="language" value={language} onChange={(e) => setLanguage(e.target.value)}
                      className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 appearance-none transition">
                      {languageOptions.map(option => (<option key={option} value={option}>{option}</option>))}
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="voice" className="block text-sm font-medium text-gray-300 mb-2">Giọng đọc AI</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><SpeakerWaveIcon className="h-5 w-5 text-gray-400" /></div>
                    <select id="voice" value={voice} onChange={(e) => setVoice(e.target.value)}
                      className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 appearance-none transition">
                      {voiceOptions.map(option => (<option key={option} value={option}>{option}</option>))}
                    </select>
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="scriptDuration" className="block text-sm font-medium text-gray-300 mb-2">Thời lượng kịch bản</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3"><ClockIcon className="h-5 w-5 text-gray-400" /></div>
                    <select id="scriptDuration" value={scriptDuration} onChange={(e) => setScriptDuration(e.target.value)}
                      className="w-full bg-gray-900 border border-gray-600 rounded-lg py-3 pl-10 pr-4 text-gray-100 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 appearance-none transition">
                      {durationOptions.map(option => (<option key={option.value} value={option.value}>{option.label}</option>))}
                    </select>
                  </div>
                </div>
            </div>
             <p className="text-sm text-gray-400 -mt-3 text-center">
                Ước tính sẽ tạo ra khoảng <span className="font-bold text-cyan-400">{numberOfScenes}</span> phân cảnh.
            </p>
        </div>
       

        {error && <p className="text-sm text-red-400">{error}</p>}
        
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center items-center bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-500 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 disabled:cursor-not-allowed shadow-lg shadow-cyan-900/50 uppercase tracking-wider"
        >
          {isLoading ? 'Đang xử lý...' : (scriptType === 'analysis' ? 'Phân tích & Tạo kịch bản' : 'Tạo kịch bản nối tiếp')}
        </button>
      </form>
    </div>
  );
};
