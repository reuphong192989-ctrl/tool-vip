
import React from 'react';

export const LoadingSpinner: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-full py-20">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-cyan-500"></div>
    <p className="mt-4 text-lg text-gray-300">AI đang phân tích và viết kịch bản...</p>
    <p className="mt-1 text-sm text-gray-500">Quá trình này có thể mất một lúc.</p>
  </div>
);
