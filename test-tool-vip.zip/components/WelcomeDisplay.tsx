import React from 'react';
import { ArrowLeftIcon } from './IconComponents';

export const WelcomeDisplay: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 p-8">
        <div className="flex-grow flex flex-col items-center justify-center">
            <ArrowLeftIcon className="w-16 h-16 text-gray-600 mb-4 hidden lg:block mx-auto" />
            <div className="lg:hidden w-16 h-16 text-gray-600 mb-4 animate-bounce mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 rotate-90">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25 12 21m0 0-3.75-3.75M12 21V3" />
                </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-400">Báo cáo phân tích của bạn đang chờ</h3>
            <p className="mt-2 max-w-sm mx-auto">
                Cung cấp URL của đối thủ và mục tiêu của bạn ở bên trái. AI sẽ phân tích sâu và tạo ra một kịch bản vượt trội để giúp bạn chiến thắng.
            </p>
        </div>

        <div className="border-t-2 border-dashed border-gray-700 mt-12 pt-8 w-full max-w-md shrink-0">
            <p className="text-lg font-semibold text-cyan-400">Công cụ được phát triển bởi Thành IT</p>
            <p className="mt-1 text-base text-gray-400">SĐT: 038 282 1682</p>
        </div>
    </div>
  );
};
