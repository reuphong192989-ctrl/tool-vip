
import React from 'react';
import { FilmIcon, BookOpenIcon } from './IconComponents';

interface HeaderProps {
    currentView: 'main' | 'library';
    setView: (view: 'main' | 'library') => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  return (
    <header className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4 md:px-8 flex justify-between items-center">
        <div className="flex items-center">
          <FilmIcon className="w-8 h-8 text-cyan-400 mr-3"/>
          <div>
            <h1 className="text-2xl font-bold text-white">Công cụ Phân tích & Tối ưu hóa Kịch bản</h1>
            <p className="text-sm text-gray-400">Phân tích đối thủ, tìm lỗ hổng nội dung và tạo kịch bản vượt trội.</p>
          </div>
        </div>
        <button
            onClick={() => setView(currentView === 'main' ? 'library' : 'main')}
            className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg transition-colors duration-300"
        >
            <BookOpenIcon className="w-5 h-5"/>
            {currentView === 'main' ? 'Thư viện Phân tích' : 'Công cụ'}
        </button>
      </div>
    </header>
  );
};
