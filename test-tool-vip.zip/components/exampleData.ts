import type { SeriesBible, Scene, CharacterProfile } from '../types';

// Dựa trên tệp application/json do người dùng cung cấp
const characterProfiles: CharacterProfile[] = [
  {
    name: 'Capy (Lão Tí)',
    description: 'Một con Capybara trưởng thành. Là động vật, không phải hình người. Bị ám ảnh bởi đồ ăn/giấc ngủ.',
    appearance: 'To, béo, mắt lim dim buồn ngủ, đội mũ tai bèo màu xanh lá cây. Mí mắt luôn khép hờ, vẻ mặt thường trực buồn ngủ, đờ đẫn và bất cần.',
    personality: 'Lười biếng, không có động lực, khôn ngầm và bất cần.',
    voice_profile: 'Trầm, chậm, đều đều, hơi nghẹt (giọng Hà Nội/Bắc Bộ).'
  },
  {
    name: 'Bé An',
    description: "Cô bé Việt Nam 5 tuổi. Là 'Người sáng tạo nội dung'.",
    appearance: 'Vóc dáng nhỏ bé, khuôn mặt tròn biểu cảm, đôi mắt to, tròn, vô cùng tò mò. Tóc bob đen ngắn. Trang phục: Áo phông màu vàng tươi và quần yếm jean màu xanh đậm.',
    personality: 'Năng lượng cao và cực kỳ quyết đoán. Năng động, tham vọng, ngây thơ và bảo vệ Capy.',
    voice_profile: 'Cao, trong, sáng và nhiệt tình (giọng miền Nam).'
  },
  {
    name: 'Mẹ An (Mẹ)',
    description: 'Một phụ nữ tốt bụng ở độ tuổi 30.',
    appearance: 'Nét mặt mềm mại, tròn trịa, đậm chất mẹ. Dịu dàng và yêu thương, thường nở nụ cười ấm áp. Mặc đồ bộ ở nhà đơn giản, gọn gàng.',
    personality: 'Ủng hộ, tốt bụng nhưng cứng rắn khi cần thiết.',
    voice_profile: 'Ấm áp, quan tâm và nhẹ nhàng (giọng miền Nam).'
  },
  {
    name: 'Bác Bảy',
    description: 'Một người đàn ông lớn tuổi (60 tuổi) trong làng, đóng vai trò là người phán xử/người có thẩm quyền.',
    appearance: 'Khuôn mặt sắc sảo, hay hoài nghi và bộ râu dê dài, mỏng màu xám. Mặc áo gilê bạc màu và đội mũ lưỡi trai nhỏ.',
    personality: 'Nghiêm khắc, nghiêm túc, thường hay nghi ngờ, nhưng thầm có một mặt vụng về.',
    voice_profile: 'Khàn, hơi giọng mũi và nghiêm nghị (giọng miền Nam chuẩn).'
  }
];

export const LAO_TI_SERIES_BIBLE: SeriesBible = {
  ho_so_nhan_vat: characterProfiles,
  phong_cach_hinh_anh: "Ảnh 8K điện ảnh, chân thực, ánh sáng kịch tính, lấy nét sắc sảo, siêu chi tiết, màu sắc rực rỡ. CGI được sử dụng cho các cảnh quay phản ứng của Capy.",
  tong_giong: "Hài hước ngớ ngẩn, Hài kịch tình huống (Slapstick), Ấm áp.",
  boi_canh_chung: "Một ngôi nhà ngoại ô ấm cúng, sáng sủa trong bối cảnh làng quê Việt Nam. Các khu vực chính bao gồm Bếp, Phòng khách và Sân sau/Hiên nhà đầy nắng."
};

export const EXAMPLE_LAST_SCENE: Scene = {
    sceneNumber: 15,
    setting: "Phòng khách, xế chiều.",
    imagePrompt: "Ảnh 8K điện ảnh, chân thực, ánh sáng kịch tính... Một cô bé Việt Nam 5 tuổi (Bé An) đang hào hứng cho một con Capybara to béo (Capy) đội mũ tai bèo màu xanh xem màn hình điện thoại, Capy tỏ vẻ không mấy ấn tượng, ngồi trên một chiếc ghế lười.",
    negativeImagePrompt: "biến dạng, mờ, xấu xí, tay xấu, hoạt hình, anime",
    motionPrompt: {
        character: "Bé An: Một cô bé Việt Nam 5 tuổi, năng động, tham vọng... đang cho Capy xem điện thoại. Capy: Một con Capybara trưởng thành, to, béo, mắt lim dim... trông có vẻ buồn chán.",
        setting: "Phòng khách ấm cúng, ánh nắng chiếu qua cửa sổ.",
        lighting: "Ánh sáng ấm áp của buổi chiều.",
        action: "Bé An giơ điện thoại lên, chỉ vào màn hình một cách vui sướng. Capy từ từ chớp mắt, không nhúc nhích.",
        dialogue: "Lão Tí ơi, con có ý tưởng này đỉnh của chóp luôn! Ngày mai mình quay mukbang nha!",
        camera_movement: "Cận cảnh vào khuôn mặt phấn khích của Bé An, sau đó lia máy chậm ra để thấy phản ứng không cảm xúc của Capy.",
        sound_effects: "Tiếng chuông 'ý tưởng' vui tươi, tiếng dế kêu nhẹ bên ngoài.",
        background_music: "Nhạc không lời vui tươi và nhẹ nhàng tắt dần.",
        visuals_notes: "Nhấn mạnh sự đối lập giữa vẻ hào hứng của An và sự bất biến của Capy.",
        negativeMotionPrompt: "máy quay rung lắc, ngoại hình nhân vật không nhất quán, ánh sáng tối"
    }
};

export const EXAMPLE_NEW_EPISODE_TOPIC = "Lão Tí Capybara lần đầu làm mukbang ASMR và gặp sự cố dở khóc dở cười với món mắm tôm.";