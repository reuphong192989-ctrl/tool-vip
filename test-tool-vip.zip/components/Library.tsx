
import React from 'react';
import type { AnalysisAndScript } from '../types';
import { TrashIcon, DownloadIcon } from './IconComponents';

interface LibraryProps {
  library: AnalysisAndScript[];
  onLoad: (result: AnalysisAndScript) => void;
  onDelete: (resultId: string) => void;
}

export const Library: React.FC<LibraryProps> = ({ library, onLoad, onDelete }) => {
  if (library.length === 0) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-gray-400">Thư viện của bạn trống</h2>
        <p className="text-gray-500 mt-2">Hãy thực hiện một phân tích và lưu lại để xem ở đây.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-3xl font-bold text-white mb-6">Thư viện Phân tích</h2>
      {library.map((result) => (
        <div key={result.id} className="bg-gray-800 p-4 rounded-lg flex items-center justify-between border border-gray-700 hover:border-cyan-500 transition-colors">
          <div>
            <p className="font-bold text-lg text-cyan-400">Phân tích - {new Date(parseInt(result.id.split('_')[1])).toLocaleString()}</p>
            <p className="text-sm text-gray-400 truncate max-w-xl">{result.optimizedScript.overview.tom_tat}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onLoad(result)}
              className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition"
              aria-label="Tải phân tích"
            >
              <DownloadIcon className="w-5 h-5" />
            </button>
            <button
              onClick={() => onDelete(result.id)}
              className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-md transition"
              aria-label="Xóa phân tích"
            >
              <TrashIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};
