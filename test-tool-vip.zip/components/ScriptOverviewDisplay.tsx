
import React from 'react';
import type { ScriptOverview, SeoInfo, CharacterProfile } from '../types';
import { TagIcon } from './IconComponents';

interface ScriptOverviewDisplayProps {
  overview: ScriptOverview;
  seo: SeoInfo;
}

const KeywordList: React.FC<{ keywords: string[], className?: string }> = ({ keywords, className }) => (
    <div className="flex flex-wrap gap-2">
      {(keywords || []).map(keyword => (
        <span key={keyword} className={`px-3 py-1 text-sm rounded-full ${className}`}>
          {keyword}
        </span>
      ))}
    </div>
);

const CharacterCard: React.FC<{ character: CharacterProfile }> = ({ character }) => (
  <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
    <h5 className="font-bold text-lg text-amber-300">{character.name}</h5>
    <div className="mt-2 space-y-2 text-sm">
      <p><strong className="text-gray-400">Mô tả:</strong> <span className="text-gray-200">{character.description}</span></p>
      <p><strong className="text-gray-400">Ngoại hình:</strong> <span className="text-gray-200">{character.appearance}</span></p>
      <p><strong className="text-gray-400">Tính cách:</strong> <span className="text-gray-200">{character.personality}</span></p>
      <p><strong className="text-gray-400">Hồ sơ Giọng nói:</strong> <span className="text-gray-200">{character.voice_profile}</span></p>
    </div>
  </div>
);


export const ScriptOverviewDisplay: React.FC<ScriptOverviewDisplayProps> = ({ overview, seo }) => {
  return (
    <>
        <div className="bg-gray-900/50 p-5 rounded-xl border border-cyan-700 mb-6">
        <h3 className="text-2xl font-bold text-cyan-400 mb-4">Tổng quan kịch bản</h3>
        <div className="space-y-4">
            <div>
            <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Tóm tắt</h4>
            <p className="text-gray-200 mt-1">{overview.tom_tat}</p>
            </div>
            <div>
            <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Bối cảnh</h4>
            <p className="text-gray-200 mt-1">{overview.boi_canh}</p>
            </div>
            <div>
            <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Tông giọng</h4>
            <p className="text-gray-200 mt-1">{overview.tong_giong}</p>
            </div>
             <div>
            <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Phong cách hình ảnh</h4>
            <p className="text-gray-200 mt-1">{overview.phong_cach_hinh_anh}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Hồ sơ nhân vật</h4>
              <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                {(overview.ho_so_nhan_vat || []).map(char => (
                  <CharacterCard key={char.name} character={char} />
                ))}
              </div>
            </div>
        </div>
        </div>
        
        {seo && (
        <div className="bg-gray-900/50 p-5 rounded-xl border border-cyan-700 mb-6">
            <h3 className="text-2xl font-bold text-cyan-400 mb-4 flex items-center">
                <TagIcon className="w-6 h-6 mr-3" />
                Tối ưu SEO
            </h3>
            <div className="space-y-4">
                <div>
                    <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Tiêu đề đề xuất</h4>
                    <p className="text-gray-200 mt-1 text-lg font-semibold">{seo.tieu_de}</p>
                </div>
                <div>
                    <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Từ khóa chính</h4>
                    <div className="mt-2">
                        <KeywordList keywords={seo.tu_khoa_chinh} className="bg-cyan-800 text-cyan-100 font-medium" />
                    </div>
                </div>
                <div>
                    <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Từ khóa phụ</h4>
                    <div className="mt-2">
                         <KeywordList keywords={seo.tu_khoa_phu} className="bg-gray-700 text-gray-200" />
                    </div>
                </div>
                <div>
                    <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Từ khóa liên quan</h4>
                    <div className="mt-2">
                         <KeywordList keywords={seo.tu_khoa_lien_quan} className="bg-gray-700 text-gray-300" />
                    </div>
                </div>
            </div>
        </div>
        )}
    </>
  );
};