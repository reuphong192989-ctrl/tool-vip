import React from 'react';
import type { Script, Suggestions, Scene } from '../types';
import { CopyIcon, CheckIcon } from './IconComponents';
import { ScriptOverviewDisplay } from './ScriptOverviewDisplay';

const CopyButton: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="absolute top-1/2 -translate-y-1/2 right-2 p-1.5 bg-gray-700/50 hover:bg-gray-600/70 rounded-md text-gray-300 transition"
      aria-label="Sao chép"
    >
      {copied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
    </button>
  );
};

const SceneCard: React.FC<{ scene: Scene }> = ({ scene }) => {
  const motionPromptText = JSON.stringify(scene.motionPrompt, null, 2);

  const handleFocus = (event: React.FocusEvent<HTMLTextAreaElement | HTMLInputElement>) => event.target.select();

  return (
    <div className="bg-gray-900/50 p-5 rounded-xl border border-gray-700 mb-6 transition-shadow hover:shadow-cyan-900/20 hover:shadow-lg">
      <h3 className="text-xl font-bold text-cyan-400 mb-3">Cảnh {scene.sceneNumber}: {scene.setting}</h3>
      <div className="space-y-4">
        <div>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Ghi chú sản xuất</p>
            <p className="text-gray-200 italic p-3 bg-gray-800 rounded-md">"{scene.motionPrompt.visuals_notes}"</p>
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Prompt ảnh</p>
          <div className="relative">
            <input type="text" readOnly value={scene.imagePrompt} onFocus={handleFocus} className="w-full bg-gray-800 text-sm text-amber-300 p-3 rounded-md border border-gray-700 focus:outline-none focus:ring-1 focus:ring-cyan-500 pr-10 cursor-pointer" />
            <CopyButton textToCopy={scene.imagePrompt} />
          </div>
        </div>
         <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Negative Prompt Ảnh</p>
          <div className="relative">
            <input type="text" readOnly value={scene.negativeImagePrompt} onFocus={handleFocus} className="w-full bg-gray-800 text-sm text-red-300 p-3 rounded-md border border-gray-700 focus:outline-none focus:ring-1 focus:ring-cyan-500 pr-10 cursor-pointer" />
            <CopyButton textToCopy={scene.negativeImagePrompt} />
          </div>
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Prompt chuyển động & âm thanh (JSON)</p>
           <div className="relative">
            <textarea readOnly value={motionPromptText} onFocus={handleFocus} rows={5}
                className="w-full bg-gray-800 text-sm text-purple-300 p-3 rounded-md border border-gray-700 focus:outline-none focus:ring-1 focus:ring-cyan-500 pr-10 cursor-pointer font-mono" />
            <CopyButton textToCopy={JSON.stringify(scene.motionPrompt)} />
          </div>
        </div>
      </div>
    </div>
  );
};

interface OptimizedScriptDisplayProps {
  script: Script;
  suggestions: Suggestions;
}

const renderSceneSection = (title: string, scenes: Scene[]) => {
    if (!scenes || scenes.length === 0) return null;
    return (
        <>
            <h2 className="text-2xl font-semibold text-cyan-300 mt-8 mb-4 border-b-2 border-cyan-800 pb-2">{title}</h2>
            {scenes.map((scene) => (
              <SceneCard key={scene.sceneNumber} scene={scene} />
            ))}
        </>
    )
}

export const OptimizedScriptDisplay: React.FC<OptimizedScriptDisplayProps> = ({ script, suggestions }) => {
  return (
    <div className="animate-fade-in">
        <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-900/50 p-5 rounded-xl border border-cyan-700">
                <h3 className="text-xl font-bold text-cyan-400 mb-3">Đề xuất 5 Tiêu đề</h3>
                <ul className="list-decimal list-inside space-y-2 text-gray-200">
                    {suggestions.titles.map((title, i) => <li key={i}>{title}</li>)}
                </ul>
            </div>
            <div className="bg-gray-900/50 p-5 rounded-xl border border-cyan-700">
                <h3 className="text-xl font-bold text-cyan-400 mb-3">Đề xuất 5 Ý tưởng Thumbnail</h3>
                <ul className="list-decimal list-inside space-y-2 text-gray-200">
                    {suggestions.thumbnailIdeas.map((idea, i) => <li key={i}>{idea}</li>)}
                </ul>
            </div>
        </div>
      
        <ScriptOverviewDisplay overview={script.overview} seo={script.seo} />
        {renderSceneSection('Mở đầu (Intro/Hook)', script.intro)}
        {renderSceneSection('Thân bài (Body/Content)', script.body)}
        {renderSceneSection('Kết luận (Outro/CTA)', script.outro)}
    </div>
  );
};
